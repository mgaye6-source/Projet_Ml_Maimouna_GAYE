"""Entraînement d'un détecteur d'attaques réseau (Projet 2).

Usage (depuis la racine du dépôt) : python src/train.py
- explore rapidement les données ;
- compare plusieurs modèles (Pipeline avec prétraitement) sur un jeu de validation ;
- ré-entraîne le meilleur sur toutes les données ;
- enregistre le modèle dans models/model.joblib.
"""
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

RACINE = Path(__file__).resolve().parent.parent
DONNEES = RACINE / "data" / "flux_train.csv"
MODELE = RACINE / "models" / "model.joblib"
SEED = 42

CIBLE = "attaque"
COL_CAT = ["protocol"]
COL_NUM = ["duration", "dst_port", "src_bytes", "dst_bytes", "nb_packets",
           "nb_failed_logins", "nb_conn_same_host", "syn_rate"]


def explorer(df):
    print("Taille :", df.shape)
    print("\nValeurs manquantes :\n", df.isna().sum()[df.isna().sum() > 0])
    print("\nRépartition de la cible :\n", df[CIBLE].value_counts(normalize=True).round(3))


def construire_pipeline(modele, echelle=True):
    """Prétraitement (imputation, mise à l'échelle, encodage) + modèle."""
    etapes_num = [("imputer", SimpleImputer(strategy="median"))]
    if echelle:
        etapes_num.append(("scaler", StandardScaler()))
    pretraitement = ColumnTransformer([
        ("num", Pipeline(etapes_num), COL_NUM),
        ("cat", OneHotEncoder(handle_unknown="ignore"), COL_CAT),
    ])
    return Pipeline([("prep", pretraitement), ("modele", modele)])


def main():
    df = pd.read_csv(DONNEES)
    explorer(df)
    X, y = df[COL_NUM + COL_CAT], df[CIBLE]

    candidats = {
        "Régression logistique": construire_pipeline(
            LogisticRegression(max_iter=1000, class_weight="balanced")),
        "Arbre de décision": construire_pipeline(
            DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=SEED),
            echelle=False),
        "Forêt aléatoire": construire_pipeline(
            RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                   random_state=SEED, n_jobs=-1),
            echelle=False),
    }

    # Jeu de validation (20 %), stratifié pour garder la proportion d'attaques
    X_tr, X_val, y_tr, y_val = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

    scores = {}
    for nom, pipe in candidats.items():
        pipe.fit(X_tr, y_tr)
        pred = pipe.predict(X_val)
        f1 = f1_score(y_val, pred)
        f1_cv = cross_val_score(pipe, X, y, cv=cv, scoring="f1").mean()
        scores[nom] = f1_cv
        print(f"\n===== {nom} =====")
        print(classification_report(y_val, pred, target_names=["normal", "attaque"], digits=3))
        tn, fp, fn, tp = confusion_matrix(y_val, pred).ravel()
        print(f"Matrice de confusion : VN={tn} FP={fp} FN={fn} VP={tp}")
        print(f"F1 (attaque) validation = {f1:.3f} | F1 validation croisée (5 plis) = {f1_cv:.3f}")

    # Meilleur modèle selon le F1 en validation croisée (plus stable qu'un seul découpage)
    meilleur = max(scores, key=scores.get)
    print(f"\nModèle retenu : {meilleur} (F1 CV = {scores[meilleur]:.3f})")

    final = candidats[meilleur]
    final.fit(X, y)  # ré-entraînement sur toutes les données
    MODELE.parent.mkdir(exist_ok=True)
    joblib.dump(final, MODELE)
    print("Modèle enregistré dans", MODELE)


if __name__ == "__main__":
    main()
