"""Prédiction avec le modèle entraîné (Projet 2).

La fonction predict(df) est appelée par le correcteur automatique.
"""
from pathlib import Path

import joblib
import pandas as pd

MODELE = Path(__file__).resolve().parent.parent / "models" / "model.joblib"
COLONNES = ["duration", "dst_port", "src_bytes", "dst_bytes", "nb_packets",
            "nb_failed_logins", "nb_conn_same_host", "syn_rate", "protocol"]

_modele = None


def predict(df: pd.DataFrame) -> list:
    """df : mêmes colonnes que flux_train.csv, SANS 'attaque'.
    Retourne une liste de 0 (normal) ou 1 (attaque), une valeur par ligne."""
    global _modele
    if _modele is None:
        _modele = joblib.load(MODELE)
    X = df[COLONNES]
    return [int(p) for p in _modele.predict(X)]


if __name__ == "__main__":
    flux = pd.read_csv(Path(__file__).resolve().parent.parent / "data" / "flux_train.csv")
    pred = predict(flux.drop(columns=["attaque"]).head(10))
    print("Prédictions :", pred)
    print("Réalité     :", flux["attaque"].head(10).tolist())
